create
    definer = root@localhost procedure addCategory(IN pName varchar(50), IN pStatus bit)
begin
    insert into category (name, status) VALUES (pName, pStatus);
end;

