create
    definer = root@localhost procedure getAllCategories()
begin
    select * from category;
end;

