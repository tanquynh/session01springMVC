create
    definer = root@localhost procedure deleteProductById(IN pId int)
begin
    delete from product where id = pId;
end;

