create
    definer = root@localhost procedure getProductById(IN pId int)
begin
    select * from product where id = pId;
end;

