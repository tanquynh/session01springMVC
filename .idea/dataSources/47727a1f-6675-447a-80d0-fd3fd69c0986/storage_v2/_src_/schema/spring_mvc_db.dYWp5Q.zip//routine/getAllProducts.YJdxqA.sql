create
    definer = root@localhost procedure getAllProducts()
begin
    select * from product;
end;

