create
    definer = root@localhost procedure updateProductById(IN pName varchar(100), IN pPrice float, IN pImage text,
                                                         IN pCategoryId int, IN pStatus bit, IN pId int)
begin
    update product set name = pName, price = pPrice, image = pImage, category_id = pCategoryId, status = pStatus where id = pId;
end;

